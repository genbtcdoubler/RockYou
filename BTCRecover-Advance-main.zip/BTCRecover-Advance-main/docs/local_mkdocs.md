# Running documentation locally

You can also view this documentation on your PC, even if it is air-gapped.

After Python is installed as per the installation guide, run the following commands from the btcrecover folder.

`pip3 install -r ./docs/requirements.txt`

Once that has complete run...

`mkdocs serve`

You will then be able to access the documentation in your browser at [http://127.0.0.1:8000](http://127.0.0.1:8000)